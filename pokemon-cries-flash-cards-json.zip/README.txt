A Pen created at CodePen.io. You can find this one at https://codepen.io/randykomforty/pen/10c1bdc42e7b64609e5214f3af4e50dc.

 